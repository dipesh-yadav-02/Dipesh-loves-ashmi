
function triggerBird() {
  document.getElementById('bird').classList.remove('hidden');
  document.getElementById('bird').style.top = '10%';
  document.getElementById('bird').style.left = '80%';
  setTimeout(() => {
    document.getElementById('letterContainer').classList.remove('hidden');
    document.getElementById('bird').classList.add('hidden');
    document.getElementById('overlay').style.display = 'block';
  }, 3000);
}

const fullMessage = `Happy Birthday, my dearest Ashmi ❤️
You’re not just special today — you’re special every single day.
But today, you truly deserve the world.
I love you more than words could ever express.
I will love you forever, endlessly.
I wish that we celebrate all your birthdays together,
with love, laughter, and a heart full of joy.
May every birthday of yours be more beautiful, more magical,
and more special than the last — because you deserve nothing less 💖

~your Dipesh`;

function showMessage() {
  const messageBox = document.getElementById('messageBox');
  const messageText = document.getElementById('messageText');
  messageBox.classList.remove('hidden');
  let i = 0;
  function typeWriter() {
    if (i < fullMessage.length) {
      messageText.innerHTML += fullMessage.charAt(i);
      i++;
      setTimeout(typeWriter, 50);
    }
  }
  typeWriter();
}
